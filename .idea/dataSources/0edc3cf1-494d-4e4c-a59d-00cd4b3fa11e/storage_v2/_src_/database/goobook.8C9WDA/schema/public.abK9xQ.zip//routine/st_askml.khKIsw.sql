create function st_askml(version integer, geog geography, maxdecimaldigits integer DEFAULT 15, nprefix text DEFAULT NULL::text)
  returns text
immutable
language sql
as $$
SELECT public._ST_AsKML($1, $2, $3, $4)
$$;

comment on function st_askml(version integer, geog geography, maxdecimaldigits integer DEFAULT 15,
                             nprefix text DEFAULT NULL :: text)
is 'args: version, geog, maxdecimaldigits=15, nprefix=NULL - Return the geometry as a KML element. Several variants. Default version=2, default precision=15';

