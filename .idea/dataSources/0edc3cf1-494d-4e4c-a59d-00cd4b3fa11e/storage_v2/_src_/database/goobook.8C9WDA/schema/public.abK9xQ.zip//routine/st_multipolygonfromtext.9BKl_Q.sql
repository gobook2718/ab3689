create function st_multipolygonfromtext(text, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT public.ST_MPolyFromText($1, $2)
$$;

