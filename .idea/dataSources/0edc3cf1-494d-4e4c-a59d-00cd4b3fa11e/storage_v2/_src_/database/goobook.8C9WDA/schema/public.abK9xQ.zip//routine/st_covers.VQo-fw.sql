create function st_covers(text, text)
  returns boolean
immutable
language sql
as $$
SELECT ST_Covers($1::public.geometry, $2::public.geometry);
$$;

