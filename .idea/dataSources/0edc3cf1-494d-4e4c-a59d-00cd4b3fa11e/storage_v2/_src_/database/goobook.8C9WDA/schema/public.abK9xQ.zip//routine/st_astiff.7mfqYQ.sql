create function st_astiff(rast raster, nbands integer[], compression text, srid integer DEFAULT NULL::integer)
  returns bytea
immutable
language sql
as $$
SELECT st_astiff(st_band($1, $2), $3, $4)
$$;

comment on function st_astiff(rast raster, nbands integer [], compression text, srid integer DEFAULT NULL :: integer)
is 'args: rast, nbands, compression='', srid=sameassource - Return the raster selected bands as a single TIFF image (byte array). If no band is specified, then will try to use all bands.';

