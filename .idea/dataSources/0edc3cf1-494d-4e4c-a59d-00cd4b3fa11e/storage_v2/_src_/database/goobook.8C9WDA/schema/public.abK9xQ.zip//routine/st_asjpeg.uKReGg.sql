create function st_asjpeg(rast raster, nband integer, quality integer)
  returns bytea
immutable
strict
language sql
as $$
SELECT public.st_asjpeg($1, ARRAY[$2], $3)
$$;

comment on function st_asjpeg(rast raster, nband integer, quality integer)
is 'args: rast, nband, quality - Return the raster tile selected bands as a single Joint Photographic Exports Group (JPEG) image (byte array). If no band is specified and 1 or more than 3 bands, then only the first band is used. If only 3 bands then all 3 bands are used and mapped to RGB.';

