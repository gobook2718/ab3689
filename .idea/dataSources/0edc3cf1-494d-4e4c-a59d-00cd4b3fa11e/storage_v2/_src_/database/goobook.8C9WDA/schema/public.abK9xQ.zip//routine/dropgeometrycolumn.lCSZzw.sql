create function dropgeometrycolumn(table_name character varying, column_name character varying)
  returns text
strict
language plpgsql
as $$
DECLARE
	ret text;
BEGIN
	SELECT public.DropGeometryColumn('','',$1,$2) into ret;
	RETURN ret;
END;
$$;

comment on function dropgeometrycolumn(table_name character varying, column_name character varying)
is 'args: table_name, column_name - Removes a geometry column from a spatial table.';

