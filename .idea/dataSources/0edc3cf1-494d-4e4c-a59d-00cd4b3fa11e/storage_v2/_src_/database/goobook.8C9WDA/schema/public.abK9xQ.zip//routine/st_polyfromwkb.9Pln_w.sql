create function st_polyfromwkb(bytea, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1, $2)) = 'POLYGON'
	THEN public.ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;

