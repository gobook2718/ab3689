create function st_coveredby(text, text)
  returns boolean
immutable
language sql
as $$
SELECT ST_CoveredBy($1::public.geometry, $2::public.geometry);
$$;

