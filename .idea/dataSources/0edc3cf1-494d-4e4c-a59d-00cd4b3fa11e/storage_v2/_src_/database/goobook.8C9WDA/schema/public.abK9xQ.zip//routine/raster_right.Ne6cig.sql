create function raster_right(raster, raster)
  returns boolean
immutable
strict
language sql
as $$
select $1::geometry >> $2::geometry
$$;

